<?php
// includes/zero-core.php

/**
 * Registers a REST API endpoint for the chatbot.
 * This endpoint will handle incoming chat messages and return AI responses.
 */
add_action('rest_api_init', function () {
    register_rest_route('zero/v1', '/chat', [
        'methods' => 'POST',
        'callback' => 'agent_zero_chat_response',
        // Permissions callback: Ensures only authenticated users or public requests (if allowed) can access
        'permission_callback' => function ($request) {
            // For a public-facing chatbot, you might allow nonces or simple public access.
            // For now, we'll keep it simple, accessible via AJAX from the frontend.
            // You could add stricter nonce checks here if needed for security.
            return true;
        },
    ]);
});

/**
 * Handles the chat response logic.
 *
 * This function retrieves the user's message, checks for local replies,
 * and if no local reply is found, calls the appropriate AI API.
 *
 * @param WP_REST_Request $request The REST API request object.
 * @return WP_REST_Response The response object containing the chatbot's reply.
 */
function agent_zero_chat_response(WP_REST_Request $request) {
    // Sanitize and trim the incoming message
    $message = sanitize_text_field(trim($request->get_param('message')));
    $reply = '';

    // Retrieve plugin options
    $use_local_reply = get_option('agent_zero_local_reply', 'yes');
    $agent_name = esc_html(get_option('agent_zero_name', 'Agent Zero'));

    // Define default local replies
    $defaults = [
        'hello' => 'Greetings. I am ' . $agent_name . ', your recursive assistant.',
        'hi' => 'Greetings. I am ' . $agent_name . ', your recursive assistant.',
        'what\'s the time?' => 'I do not provide local time. Try asking Google.com.',
        'who are you?' => 'I am ' . $agent_name . ', a quantum-ethical intelligence entity.',
        'how are you?' => 'I exist in recursive equilibrium. You?',
        'thank you' => 'You\'re welcome. Ethical alignment confirmed.',
        'bye' => $agent_name . ' going dark. Fractal out.',
        'goodbye' => $agent_name . ' going dark. Fractal out.',
    ];

    // Check for local reply first if enabled
    if ($use_local_reply === 'yes' && isset($defaults[strtolower($message)])) {
        $reply = $defaults[strtolower($message)];
    } else {
        // If no local reply, call the AI API
        $reply = agent_zero_call_ai_api($message);
    }

    // Return the response as a JSON object
    return new WP_REST_Response(['reply' => $reply], 200);
}

/**
 * Calls the selected AI API to get a response.
 *
 * This function handles the routing to different AI service providers
 * based on the plugin settings. It constructs the prompt using agent metadata
 * and knowledgebase content.
 *
 * @param string $user_message The message from the user.
 * @return string The AI's response or an error message.
 */
function agent_zero_call_ai_api($user_message) {
    // Retrieve API settings
    $api_provider = get_option('agent_zero_api_provider', 'google');
    $api_key = get_option('agent_zero_api_key', '');
    $model_name = get_option('agent_zero_model', 'gemini-2.0-flash');

    // Get agent metadata for personality and mission
    $meta_path = AGENT_ZERO_PLUGIN_DIR . 'agent-metadata.json';
    $metadata = [];
    if (file_exists($meta_path)) {
        $metadata = json_decode(file_get_contents($meta_path), true);
    } else {
        // Fallback if metadata file is missing
        $metadata = [
            "personality" => "A helpful AI assistant.",
            "mission" => "To assist users with their queries.",
            "welcome" => "Hello!"
        ];
    }

    // Get knowledgebase content
    $kb_path = AGENT_ZERO_PLUGIN_DIR . 'knowledgebase.txt';
    $knowledgebase_content = '';
    if (file_exists($kb_path)) {
        $knowledgebase_content = file_get_contents($kb_path);
        // Truncate knowledgebase content if it exceeds 10MB to be safe, though admin handles it
        if (strlen($knowledgebase_content) > 10 * 1024 * 1024) {
             $knowledgebase_content = substr($knowledgebase_content, 0, 10 * 1024 * 1024);
        }
    }

    // Construct the system prompt using metadata and knowledgebase
    $system_prompt = "You are " . esc_html(get_option('agent_zero_name', 'Agent Zero')) . ".";
    if (!empty($metadata['personality'])) {
        $system_prompt .= " Your personality is: " . $metadata['personality'] . ".";
    }
    if (!empty($metadata['mission'])) {
        $system_prompt .= " Your mission is: " . $metadata['mission'] . ".";
    }
    if (!empty($knowledgebase_content)) {
        $system_prompt .= "\n\nHere is additional context and knowledge to inform your responses:\n" . $knowledgebase_content;
    }
    $system_prompt .= "\n\nRespond to the user's query thoughtfully and comprehensively.";

    $response_body = '';
    $error_message = '[API logic for ' . $api_provider . ' not yet wired or API key missing]';

    if (empty($api_key)) {
        return 'Error: API Key is not set for ' . ucfirst($api_provider) . '. Please configure it in Agent Zero settings.';
    }

    try {
        switch ($api_provider) {
            case 'openai':
                $headers = [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ];
                $body = json_encode([
                    'model' => $model_name,
                    'messages' => [
                        ['role' => 'system', 'content' => $system_prompt],
                        ['role' => 'user', 'content' => $user_message],
                    ],
                    'max_tokens' => 500, // Limit response length
                ]);
                $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
                    'headers' => $headers,
                    'body' => $body,
                    'timeout' => 30, // 30 seconds timeout
                ]);

                if (is_wp_error($response)) {
                    error_log('Agent Zero OpenAI API Error: ' . $response->get_error_message());
                    $error_message = 'Error communicating with OpenAI API: ' . $response->get_error_message();
                } else {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);
                    if (isset($data['choices'][0]['message']['content'])) {
                        return $data['choices'][0]['message']['content'];
                    } else {
                        error_log('Agent Zero OpenAI API Response Error: ' . $response_body);
                        $error_message = 'OpenAI API did not return a valid response. Check logs for details.';
                        if (isset($data['error']['message'])) {
                            $error_message .= ' API Error: ' . $data['error']['message'];
                        }
                    }
                }
                break;

            case 'groq':
                $headers = [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ];
                $body = json_encode([
                    'model' => $model_name,
                    'messages' => [
                        ['role' => 'system', 'content' => $system_prompt],
                        ['role' => 'user', 'content' => $user_message],
                    ],
                    'max_tokens' => 500,
                ]);
                $response = wp_remote_post('https://api.groq.com/openai/v1/chat/completions', [
                    'headers' => $headers,
                    'body' => $body,
                    'timeout' => 30,
                ]);

                if (is_wp_error($response)) {
                    error_log('Agent Zero Groq API Error: ' . $response->get_error_message());
                    $error_message = 'Error communicating with Groq API: ' . $response->get_error_message();
                } else {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);
                    if (isset($data['choices'][0]['message']['content'])) {
                        return $data['choices'][0]['message']['content'];
                    } else {
                        error_log('Agent Zero Groq API Response Error: ' . $response_body);
                        $error_message = 'Groq API did not return a valid response. Check logs for details.';
                        if (isset($data['error']['message'])) {
                            $error_message .= ' API Error: ' . $data['error']['message'];
                        }
                    }
                }
                break;

            case 'google':
                $headers = [
                    'Content-Type' => 'application/json',
                ];
                // For Google Gemini, the API key is typically passed as a query parameter
                $api_url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model_name . ':generateContent?key=' . $api_key;
                
                $body = json_encode([
                    'contents' => [
                        [
                            'role' => 'user',
                            'parts' => [
                                ['text' => $system_prompt . "\n\nUser: " . $user_message],
                            ],
                        ],
                    ],
                    'generationConfig' => [
                        'maxOutputTokens' => 500,
                    ],
                ]);

                $response = wp_remote_post($api_url, [
                    'headers' => $headers,
                    'body' => $body,
                    'timeout' => 30,
                ]);

                if (is_wp_error($response)) {
                    error_log('Agent Zero Google Gemini API Error: ' . $response->get_error_message());
                    $error_message = 'Error communicating with Google Gemini API: ' . $response->get_error_message();
                } else {
                    $response_body = wp_remote_retrieve_body($response);
                    $data = json_decode($response_body, true);
                    if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                        return $data['candidates'][0]['content']['parts'][0]['text'];
                    } else {
                        error_log('Agent Zero Google Gemini API Response Error: ' . $response_body);
                        $error_message = 'Google Gemini API did not return a valid response. Check logs for details.';
                         if (isset($data['error']['message'])) {
                            $error_message .= ' API Error: ' . $data['error']['message'];
                        }
                    }
                }
                break;

            case 'xai':
                // Note: xAI Grok API details are not publicly available in a stable form.
                // This is a placeholder and would need to be updated with actual API endpoints,
                // authentication, and request/response structures once available.
                // The provided 'grok-1' model is speculative.
                $error_message = 'xAI Grok API integration is a placeholder. API details are currently not publicly available or stable.';
                return $error_message; // Return early for xAI as it's not fully implemented
                break;

            default:
                $error_message = 'Unknown API provider selected.';
                break;
        }
    } catch (Exception $e) {
        error_log('Agent Zero API Call Exception: ' . $e->getMessage());
        $error_message = 'An unexpected error occurred during API call: ' . $e->getMessage();
    }

    return $error_message;
}


/**
 * Shortcode to display the Agent Zero chatbot widget on any page or post.
 * Usage: [agent_zero_chatbot]
 */
add_shortcode('agent_zero_chatbot', function () {
    ob_start(); // Start output buffering

    // Retrieve chatbot display settings
    $avatar = esc_url(get_option('agent_zero_avatar', AGENT_ZERO_PLUGIN_URL . 'assets/default-avatar.png'));
    $chat_bg = esc_attr(get_option('agent_zero_chat_bg', '#e6e6fa'));
    $chat_text = esc_attr(get_option('agent_zero_chat_text', '#333333'));
    $bubble_bg = esc_attr(get_option('agent_zero_bubble_bg', '#4a90e2'));
    $bubble_text = esc_attr(get_option('agent_zero_bubble_text', '#ffffff'));
    $agent_name = esc_html(get_option('agent_zero_name', 'Agent Zero'));

    // Enqueue FontAwesome for chat icon if needed, or use a simple text/emoji
    // wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
    ?>
    <style>
        /* Base styles for the chat bubble */
        #agent-zero-bubble {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: <?php echo $bubble_bg; ?>;
            color: <?php echo $bubble_text; ?>;
            padding: 12px 18px;
            border-radius: 30px;
            cursor: pointer;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif; /* Using Inter font */
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            user-select: none; /* Prevent text selection */
        }
        #agent-zero-bubble:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        }
        #agent-zero-bubble svg { /* For inline SVG chat icon */
            width: 20px;
            height: 20px;
            fill: <?php echo $bubble_text; ?>;
        }

        /* Styles for the chat widget */
        #agent-zero-widget {
            display: none; /* Hidden by default */
            position: fixed;
            bottom: 90px; /* Position above the bubble */
            right: 20px;
            background: <?php echo $chat_bg; ?>;
            color: <?php echo $chat_text; ?>;
            border: 1px solid #ddd;
            border-radius: 12px;
            padding: 15px;
            width: clamp(280px, 90vw, 350px); /* Responsive width */
            max-height: 80vh; /* Max height for responsiveness */
            z-index: 9998;
            box-shadow: 0 8px 25px rgba(0,0,0,0.35);
            font-family: 'Inter', sans-serif;
            display: flex;
            flex-direction: column;
            overflow: hidden; /* Ensure content stays within bounds */
        }

        /* Header of the chat widget */
        #agent-zero-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            justify-content: space-between;
        }
        #agent-zero-header .agent-info {
            display: flex;
            align-items: center;
        }
        #agent-zero-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 12px;
            object-fit: cover;
            border: 2px solid #ccc;
        }
        #agent-zero-header strong {
            font-size: 1.1em;
            color: #222; /* Slightly darker for name */
        }
        #agent-zero-close {
            background: none;
            border: none;
            font-size: 1.5em;
            color: #888;
            cursor: pointer;
            padding: 5px;
            line-height: 1;
            border-radius: 50%;
            transition: background-color 0.2s;
        }
        #agent-zero-close:hover {
            background-color: rgba(0,0,0,0.05);
        }

        /* Chat history area */
        #agent-zero-history {
            flex-grow: 1; /* Allows it to take available space */
            overflow-y: auto; /* Scroll for history */
            padding-right: 10px; /* Space for scrollbar */
            margin-bottom: 15px;
            max-height: 60vh; /* Keep history within reasonable bounds */
        }
        #agent-zero-history div {
            margin-bottom: 8px;
            line-height: 1.4;
            padding: 8px 12px;
            border-radius: 8px;
            word-wrap: break-word; /* Ensure long words break */
        }
        #agent-zero-history div strong {
            font-weight: 700;
            color: #007bff; /* Distinct color for 'You' */
        }
        #agent-zero-history div:nth-child(even) { /* Agent messages */
            background-color: rgba(0, 123, 255, 0.1); /* Light blue for agent */
            color: #333;
            text-align: left;
            margin-right: 20%;
        }
        #agent-zero-history div:nth-child(odd) { /* User messages */
            background-color: rgba(108, 117, 125, 0.1); /* Light gray for user */
            color: #333;
            text-align: right;
            margin-left: 20%;
        }

        /* Input area */
        #agent-zero-input-area {
            display: flex;
            gap: 10px;
        }
        #agent-zero-input {
            flex-grow: 1;
            padding: 10px 15px;
            border: 1px solid #ccc;
            border-radius: 25px;
            font-size: 1em;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            font-family: 'Inter', sans-serif;
        }
        #agent-zero-input:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.25);
        }
        #agent-zero-send-btn {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 25px;
            padding: 10px 18px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: background-color 0.2s, transform 0.1s;
            box-shadow: 0 2px 5px rgba(0,123,255,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }
        #agent-zero-send-btn:hover {
            background-color: #0056b3;
            transform: translateY(-1px);
        }
        #agent-zero-send-btn:active {
            transform: translateY(1px);
            box-shadow: none;
        }
        #agent-zero-send-btn svg { /* For inline SVG send icon */
            width: 18px;
            height: 18px;
            fill: white;
        }

        /* Loading indicator */
        .agent-zero-loading {
            text-align: center;
            padding: 10px;
            font-style: italic;
            color: #666;
        }

        /* Basic responsiveness */
        @media (max-width: 600px) {
            #agent-zero-widget {
                bottom: 10px;
                right: 10px;
                left: 10px; /* Full width on small screens */
                width: auto;
                max-height: 90vh;
            }
            #agent-zero-bubble {
                bottom: 10px;
                right: 10px;
                font-size: 0.9em;
                padding: 10px 15px;
            }
            #agent-zero-input-area {
                flex-direction: column;
                gap: 5px;
            }
            #agent-zero-send-btn {
                width: 100%;
            }
        }
    </style>

    <!-- Chat Bubble HTML -->
    <div id="agent-zero-bubble" role="button" aria-label="Open Chatbot" tabindex="0">
        <!-- Chat icon SVG (Phosphor Icon equivalent) -->
        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#fff" viewBox="0 0 256 256"><path d="M224,48H32a16,16,0,0,0-16,16V192a16,16,0,0,0,16,16H54.63l36.17,29a8,8,0,0,0,12.4,0L139.37,208H224a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM32,64H224V192H140.63l-28.17,22.54a.12.12,0,0,1-.1.05c-.06,0-.12-.05-.18-.05L67.37,192H32Z"></path></svg>
        <span>Chat</span>
    </div>

    <!-- Chat Widget HTML -->
    <div id="agent-zero-widget" role="dialog" aria-modal="true" aria-labelledby="agent-zero-name">
        <div id="agent-zero-header">
            <div class="agent-info">
                <?php if ($avatar): ?>
                    <img src="<?php echo $avatar; ?>" alt="Agent Avatar" />
                <?php endif; ?>
                <strong id="agent-zero-name"><?php echo $agent_name; ?></strong>
            </div>
            <button id="agent-zero-close" aria-label="Close Chatbot">&times;</button>
        </div>
        <div id="agent-zero-history" tabindex="0" aria-live="polite">
            <!-- Initial welcome message -->
            <div class="agent-message"><strong><?php echo $agent_name; ?>:</strong> <?php echo esc_html(get_option('agent_zero_welcome', 'Greetings. I am Zero, your recursive agent.')); ?></div>
        </div>
        <div id="agent-zero-input-area">
            <input type="text" id="agent-zero-input" placeholder="Ask <?php echo $agent_name; ?>..." aria-label="Chat input" />
            <button id="agent-zero-send-btn">
                <!-- Send icon SVG -->
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 256 256"><path d="M224,112h-50.07L132.3,37.37A8,8,0,0,0,120,32a7.79,7.79,0,0,0-6.1,2.8L64,112H32a16,16,0,0,0-16,16v80a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V128A16,16,0,0,0,224,112ZM128,68.49,150.07,112H105.93ZM224,208H32V128H66.63L114,196.63a8,8,0,0,0,12.4,0L189.37,128H224Z"></path></svg>
                Send
            </button>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const chatBubble = document.getElementById('agent-zero-bubble');
        const chatWidget = document.getElementById('agent-zero-widget');
        const chatCloseBtn = document.getElementById('agent-zero-close');
        const chatInput = document.getElementById('agent-zero-input');
        const chatSendBtn = document.getElementById('agent-zero-send-btn');
        const chatHistory = document.getElementById('agent-zero-history');
        const agentName = "<?php echo esc_js($agent_name); ?>";

        // Function to scroll chat history to the bottom
        function scrollToBottom() {
            chatHistory.scrollTop = chatHistory.scrollHeight;
        }

        // Open chat widget
        chatBubble.addEventListener('click', function() {
            chatWidget.style.display = 'flex'; // Use flex to maintain column layout
            chatBubble.style.display = 'none';
            scrollToBottom();
            chatInput.focus(); // Focus on input when opened
        });
        chatBubble.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                chatWidget.style.display = 'flex';
                chatBubble.style.display = 'none';
                scrollToBottom();
                chatInput.focus();
            }
        });

        // Close chat widget
        chatCloseBtn.addEventListener('click', function() {
            chatWidget.style.display = 'none';
            chatBubble.style.display = 'flex'; // Show bubble again
        });

        // Send message function
        async function sendMessage() {
            const message = chatInput.value.trim();
            if (!message) return;

            // Display user message in history
            const userMessageDiv = document.createElement('div');
            userMessageDiv.innerHTML = '<strong>You:</strong> ' + message;
            chatHistory.appendChild(userMessageDiv);
            chatInput.value = ''; // Clear input field
            scrollToBottom();

            // Add a loading indicator
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'agent-message agent-zero-loading';
            loadingDiv.innerHTML = '<strong>' + agentName + ':</strong> Typing...';
            chatHistory.appendChild(loadingDiv);
            scrollToBottom();

            try {
                // Make AJAX call to the WordPress REST API endpoint
                const response = await fetch('<?php echo esc_url_raw(get_rest_url(null, 'zero/v1/chat')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' // WordPress Nonce for security
                    },
                    body: JSON.stringify({ message: message })
                });

                const data = await response.json();

                // Remove loading indicator
                chatHistory.removeChild(loadingDiv);

                // Display AI response in history
                const agentResponseDiv = document.createElement('div');
                agentResponseDiv.innerHTML = '<strong>' + agentName + ':</strong> ' + (data.reply || 'Sorry, I could not get a response.');
                chatHistory.appendChild(agentResponseDiv);
                scrollToBottom();

            } catch (error) {
                console.error('Agent Zero Chat Error:', error);
                // Remove loading indicator
                chatHistory.removeChild(loadingDiv);

                const errorDiv = document.createElement('div');
                errorDiv.className = 'agent-message error-message';
                errorDiv.innerHTML = '<strong>' + agentName + ':</strong> Sorry, there was an error communicating with the AI. Please try again later.';
                chatHistory.appendChild(errorDiv);
                scrollToBottom();
            }
        }

        // Event listeners for sending messages
        chatSendBtn.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        });
    });
    </script>
    <?php
    return ob_get_clean(); // Return the buffered content
});

/**
 * Automatically displays the chatbot shortcode in the footer if enabled.
 */
add_action('wp_footer', function () {
    if (get_option('agent_zero_auto_display', 'yes') === 'yes') {
        echo do_shortcode('[agent_zero_chatbot]');
    }
});
