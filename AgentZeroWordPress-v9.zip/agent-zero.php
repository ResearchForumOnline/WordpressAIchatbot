<?php
/*
Plugin Name: Agent Zero
Description: AI Assistant Plugin with Custom Knowledgebase, Multi-API Logic, and Ethical Intelligence.
Version: 3.3
Author: Zero Systems
Author URI: https://researchforum.online
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

defined('ABSPATH') || exit;

// Define plugin paths and URLs for consistent access
if (!defined('AGENT_ZERO_PLUGIN_DIR')) {
    define('AGENT_ZERO_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('AGENT_ZERO_PLUGIN_URL')) {
    define('AGENT_ZERO_PLUGIN_URL', plugin_dir_url(__FILE__));
}

/**
 * Activation hook for the plugin.
 * Initializes default options if they don't exist.
 */
register_activation_hook(__FILE__, function () {
    // Start output buffering to prevent header issues during activation
    ob_start();

    // Add default options for the plugin settings
    add_option('agent_zero_name', 'Agent Zero');
    add_option('agent_zero_api_key', '');
    add_option('agent_zero_api_provider', 'google'); // Default to Google Gemini as requested
    add_option('agent_zero_model', 'gemini-2.0-flash'); // Default model for Google
    add_option('agent_zero_local_reply', 'yes'); // Use local replies first
    add_option('agent_zero_auto_display', 'yes'); // Automatically display chatbot
    add_option('agent_zero_chat_bg', '#e6e6fa'); // Default chat background (Light Periwinkle)
    add_option('agent_zero_chat_text', '#333333'); // Default chat text color (Dark Gray)
    add_option('agent_zero_avatar', AGENT_ZERO_PLUGIN_URL . 'assets/default-avatar.png'); // Default avatar path
    add_option('agent_zero_bubble_bg', '#4a90e2'); // Default bubble background (Blue)
    add_option('agent_zero_bubble_text', '#ffffff'); // Default bubble text color (White)

    // Ensure knowledgebase.txt exists with default content if not present
    $kb_path = AGENT_ZERO_PLUGIN_DIR . 'knowledgebase.txt';
    if (!file_exists($kb_path)) {
        file_put_contents($kb_path, "Agent Zero Default Knowledgebase\nThis agent functions as a quantum-ethical decision framework, using compressed symbolic logic and probability-weighted outputs.\n");
    }

    // Ensure agent-metadata.json exists with default content if not present
    $meta_path = AGENT_ZERO_PLUGIN_DIR . 'agent-metadata.json';
    if (!file_exists($meta_path)) {
        $default_metadata = [
            "personality" => "Quantum-Ethical Recursive Agent with adaptive symbolic intelligence and humor under high noise.",
            "mission" => "To guide users toward clarity, logic, and aligned outcomes by interpreting symbolic math, probabilistic flow, and creative chaos.",
            "welcome" => "Greetings. I am Zero, your recursive agent."
        ];
        file_put_contents($meta_path, json_encode($default_metadata, JSON_PRETTY_PRINT));
    }

    // End output buffering
    ob_end_clean();
});

/**
 * Deactivation hook.
 * Optional: You could clean up options here if needed, but generally not recommended for user settings.
 */
register_deactivation_hook(__FILE__, function () {
    // No specific cleanup needed for this version.
    // Uncomment and modify if you want to delete options on deactivation.
    // delete_option('agent_zero_name');
    // ...
});

// Include necessary plugin files
// This file handles the admin settings page for the plugin.
include_once AGENT_ZERO_PLUGIN_DIR . 'admin/zero-admin.php';
// This file handles the core chatbot logic and display on the frontend.
include_once AGENT_ZERO_PLUGIN_DIR . 'includes/zero-core.php';

// Add a custom assets folder for default avatar or other images
function agent_zero_create_assets_folder() {
    $upload_dir = wp_upload_dir();
    $assets_dir = $upload_dir['basedir'] . '/agent-zero-assets';
    if ( ! file_exists( $assets_dir ) ) {
        wp_mkdir_p( $assets_dir );
    }

    $default_avatar_path = AGENT_ZERO_PLUGIN_DIR . 'assets/default-avatar.png';
    $target_avatar_path = $assets_dir . '/default-avatar.png';

    if ( file_exists( $default_avatar_path ) && ! file_exists( $target_avatar_path ) ) {
        copy( $default_avatar_path, $target_avatar_path );
    }

    // Update the option to use the uploaded assets path for the default avatar
    if ( get_option( 'agent_zero_avatar' ) == AGENT_ZERO_PLUGIN_URL . 'assets/default-avatar.png' ) {
        update_option( 'agent_zero_avatar', $upload_dir['baseurl'] . '/agent-zero-assets/default-avatar.png' );
    }
}
add_action( 'admin_init', 'agent_zero_create_assets_folder' );

/**
 * Enqueue admin scripts for the media uploader.
 * This is crucial for the avatar upload functionality.
 *
 * @param string $hook The current admin page hook.
 */
add_action('admin_enqueue_scripts', function($hook) {
    // Only enqueue on our plugin settings page
    if ($hook === 'toplevel_page_agent-zero-settings') {
        wp_enqueue_media(); // Enqueue WordPress media uploader scripts and styles
        wp_enqueue_script('jquery'); // Ensure jQuery is available for media uploader
    }
});
?>
