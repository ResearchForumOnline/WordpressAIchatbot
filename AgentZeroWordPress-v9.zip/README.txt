=== Agent Zero ===
Contributors: Zero Systems
Donate Link: https://researchforum.online
Tags: chatbot, AI, assistant, custom knowledge, OpenAI, Groq, Google Gemini, xAI Grok, customizable
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 3.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A versatile AI Chatbot plugin for WordPress, enabling custom knowledge bases, multiple AI API integrations, and extensive UI customization.

== Description ==
Agent Zero is a powerful WordPress plugin designed to integrate an AI-powered chatbot seamlessly into your website. It offers unparalleled flexibility, allowing you to define the chatbot's personality, mission, and welcome messages. Key features include:

Customizable Knowledge Base: Upload and edit a .txt file (up to 10MB) to provide your AI with specific information. Note: For performance, the knowledge base content is used to inform the AI's general domain, not injected directly into every prompt.

Multi-API Support: Easily switch between leading AI providers like OpenAI, Groq, Google Gemini, and a placeholder for xAI Grok.

Dynamic Model Selection: Automatically updates available AI models based on your chosen API provider.

Full UI Customization: Control the chatbot's name, avatar, chat widget colors, and chat bubble appearance directly from the WordPress admin panel.

Local Fallback Replies: Define simple, instant replies for common queries to reduce API calls.

Automatic Display: Option to automatically display the chat bubble/widget on all frontend pages.

Responsive Design: Ensures the chatbot looks and functions great on all devices (mobile, tablet, desktop).

Empower your website with an intelligent assistant that reflects your brand and provides instant support or information to your users.

== Installation ==

Download and Unzip: Download the plugin ZIP file. Unzip it to get the agent-zero folder.

Create Folder Structure:

Create a folder named agent-zero in your WordPress wp-content/plugins/ directory.

Inside agent-zero, create these subfolders: admin, includes, and assets.

Add Placeholder Image: Place a simple default-avatar.png (any small PNG image will do) inside the agent-zero/assets/ folder.

Create Empty Files: Create empty text files named knowledgebase.txt, agent-metadata.json, and README.txt directly in agent-zero. (The plugin will populate default content on activation if they are empty).

Copy File Contents: Copy the code provided in the separate blocks into their respective files:

agent-zero.php (main folder)

admin/zero-admin.php (inside admin folder)

includes/zero-core.php (inside includes folder)

Zip the Folder: Once all files are correctly placed, compress the entire agent-zero folder into a new .zip file (e.g., agent-zero.zip).

Upload to WordPress: Go to your WordPress admin dashboard, navigate to Plugins > Add New > Upload Plugin.

Activate & Configure: Activate the plugin. Then, go to the new "Agent Zero" menu item in your admin sidebar to configure your API key, choose your AI provider and model, and customize the chatbot's appearance and identity.

== Changelog ==
= 3.3 =

Refined knowledge base handling to avoid token limits (knowledge base informs AI's general domain, not direct injection).

Corrected welcome message loading from agent-metadata.json.

Enhanced CSS specificity and positioning for improved UI consistency across themes.

Added more robust error handling for API calls.

Updated default options and plugin activation logic for better out-of-the-box experience.

Improved dynamic model selection in admin settings.

Added standard plugin header fields for WordPress.org submission.

Implemented sanitization callbacks for all plugin settings for enhanced security.