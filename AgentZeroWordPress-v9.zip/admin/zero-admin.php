<?php
// admin/zero-admin.php

/**
 * Adds the top-level menu page for Agent Zero settings.
 */
add_action('admin_menu', function () {
    add_menu_page(
        'Agent Zero',               // Page title
        'Agent Zero',               // Menu title
        'manage_options',           // Capability required to access the menu
        'agent-zero-settings',      // Menu slug
        'agent_zero_settings_html', // Callback function to render the page content
        'dashicons-format-chat',    // Icon URL or Dashicons class
        80                          // Position in the menu
    );
});

/**
 * Renders the HTML content for the Agent Zero settings page.
 * This includes forms for general settings, knowledgebase, and agent identity.
 */
function agent_zero_settings_html() {
    // Define paths for knowledgebase and agent metadata files
    $kb_path = AGENT_ZERO_PLUGIN_DIR . 'knowledgebase.txt';
    $meta_path = AGENT_ZERO_PLUGIN_DIR . 'agent-metadata.json';

    // Attempt to read agent metadata, providing default if file is unreadable or invalid
    $metadata = [];
    if (file_exists($meta_path)) {
        $file_content = file_get_contents($meta_path);
        if ($file_content !== false) {
            $decoded_metadata = json_decode($file_content, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded_metadata)) {
                $metadata = $decoded_metadata;
            } else {
                // Log error if JSON is invalid
                error_log('Agent Zero: agent-metadata.json contains invalid JSON.');
                $metadata = agent_zero_get_default_metadata(); // Fallback to default
            }
        } else {
            error_log('Agent Zero: Could not read agent-metadata.json.');
            $metadata = agent_zero_get_default_metadata(); // Fallback to default
        }
    } else {
        error_log('Agent Zero: agent-metadata.json does not exist. Creating default.');
        $metadata = agent_zero_get_default_metadata(); // Fallback to default and create
        file_put_contents($meta_path, json_encode($metadata, JSON_PRETTY_PRINT));
    }

    // Default metadata function
    function agent_zero_get_default_metadata() {
        return [
            "personality" => "Quantum-Ethical Recursive Agent with adaptive symbolic intelligence and humor under high noise.",
            "mission" => "To guide users toward clarity, logic, and aligned outcomes by interpreting symbolic math, probabilistic flow, and creative chaos.",
            "welcome" => "Greetings. I am Zero, your recursive agent."
        ];
    }

    // Handle form submissions for knowledgebase and agent identity
    if (isset($_POST['save_kb']) && current_user_can('manage_options')) {
        // Sanitize and save knowledgebase content
        $content = sanitize_textarea_field($_POST['zero_kb']);
        // Check file size (10MB limit)
        if (strlen($content) > 10 * 1024 * 1024) { // 10MB in bytes
            echo "<div class='error'><p><strong>Error:</strong> Knowledgebase file size exceeds 10MB limit.</p></div>";
        } else {
            file_put_contents($kb_path, $content);
            echo "<div class='updated'><p>Knowledgebase saved.</p></div>";
        }
    }
    if (isset($_POST['reset_kb']) && current_user_can('manage_options')) {
        // Reset knowledgebase to default content
        file_put_contents($kb_path, "Agent Zero Default Knowledgebase\nThis agent functions as a quantum-ethical decision framework, using compressed symbolic logic and probability-weighted outputs.\n");
        echo "<div class='updated'><p>Knowledgebase reset to default.</p></div>";
    }
    if (isset($_POST['save_meta']) && current_user_can('manage_options')) {
        // Sanitize and save agent metadata
        $metadata['personality'] = sanitize_textarea_field($_POST['agent_personality']);
        $metadata['mission'] = sanitize_textarea_field($_POST['agent_mission']);
        $metadata['welcome'] = sanitize_text_field($_POST['agent_welcome']);
        file_put_contents($meta_path, json_encode($metadata, JSON_PRETTY_PRINT));
        echo "<div class='updated'><p>Agent identity saved.</p></div>";
    }
    ?>

    <div class="wrap">
        <h1><?php echo esc_html(get_option('agent_zero_name', 'Agent Zero')); ?> Settings</h1>
        <form method="post" action="options.php">
            <?php
                // Output necessary hidden fields for settings API
                settings_fields('agent_zero_settings_group');
                // Output settings sections and fields
                do_settings_sections('agent_zero_settings');
                // Output save changes button
                submit_button();
            ?>
        </form>

        <hr>
        <h2>Agent Data (Knowledgebase)</h2>
        <?php
        // Display knowledgebase file info
        $kb_size_kb = file_exists($kb_path) ? round(filesize($kb_path) / 1024, 2) : 0;
        $kb_last_updated = file_exists($kb_path) ? date("Y-m-d H:i:s", filemtime($kb_path)) : 'N/A';
        ?>
        <p>Stored in: <code><?php echo esc_html(basename($kb_path)); ?></code> (Size: <?php echo esc_html($kb_size_kb); ?> KB, Updated: <?php echo esc_html($kb_last_updated); ?>)</p>
        <p>Max upload size: 10MB. Content is used to provide context to the AI model.</p>
        <form method="post">
            <textarea name="zero_kb" style="width:100%; height:250px; font-family: monospace;"><?php echo esc_textarea(file_get_contents($kb_path)); ?></textarea><br/>
            <input type="submit" name="save_kb" class="button button-primary" value="Save Knowledgebase" />
            <input type="submit" name="reset_kb" class="button" value="Reset to Default" />
        </form>

        <hr>
        <h2>Agent Identity</h2>
        <p>Define Agent Zero's personality, mission, and welcome message. This metadata is sent to the AI model to shape its responses.</p>
        <form method="post">
            <label for="agent_personality">Personality:</label><br/>
            <textarea id="agent_personality" name="agent_personality" style="width:100%; height:80px;"><?php echo esc_textarea($metadata['personality'] ?? ''); ?></textarea><br/>
            <label for="agent_mission">Mission:</label><br/>
            <textarea id="agent_mission" name="agent_mission" style="width:100%; height:80px;"><?php echo esc_textarea($metadata['mission'] ?? ''); ?></textarea><br/>
            <label for="agent_welcome">Welcome Message:</label><br/>
            <input type="text" id="agent_welcome" name="agent_welcome" style="width:100%;" value="<?php echo esc_attr($metadata['welcome'] ?? ''); ?>" /><br/>
            <input type="submit" name="save_meta" class="button button-primary" value="Save Agent Identity" />
        </form>

        <hr>
        <p style="opacity:0.7; font-size:0.9em;">Plugin by <a href='https://researchforum.online' target='_blank'>researchforum.online</a>,
        <a href='https://talktoai.org' target='_blank'>talktoai.org</a>,
        <a href='https://x.com/talktoai' target='_blank'>x.com/talktoai</a></p>
    </div>
    <?php
}

/**
 * Registers all plugin settings with the WordPress Settings API.
 */
add_action('admin_init', function () {
    // --- Sanitization Callbacks ---
    // Helper function to sanitize hex colors
    function agent_zero_sanitize_hex_color($color) {
        if (preg_match('/^#([a-f0-9]{6}|[a-f0-9]{3})$/i', $color)) {
            return $color;
        }
        return ''; // Return empty string for invalid colors
    }

    // Helper function to sanitize API provider
    function agent_zero_sanitize_api_provider($provider) {
        $allowed_providers = ['openai', 'groq', 'google', 'xai'];
        if (in_array($provider, $allowed_providers)) {
            return $provider;
        }
        return 'google'; // Default to google if invalid
    }

    // Helper function to sanitize AI model
    function agent_zero_sanitize_ai_model($model) {
        $provider = get_option('agent_zero_api_provider', 'google');
        $allowed_models = [
            'openai' => ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
            'groq' => ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
            'google' => ['gemini-2.0-flash', 'gemini-2.0-pro'],
            'xai' => ['grok-1']
        ];
        if (isset($allowed_models[$provider]) && in_array($model, $allowed_models[$provider])) {
            return $model;
        }
        // Fallback to a default for the current provider if the selected model is invalid
        return $allowed_models[$provider][0] ?? 'gemini-2.0-flash';
    }

    // Helper function to sanitize yes/no options
    function agent_zero_sanitize_yes_no($value) {
        return ($value === 'yes') ? 'yes' : 'no';
    }

    // Register settings fields with sanitization callbacks
    register_setting('agent_zero_settings_group', 'agent_zero_name', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('agent_zero_settings_group', 'agent_zero_api_key', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('agent_zero_settings_group', 'agent_zero_api_provider', ['sanitize_callback' => 'agent_zero_sanitize_api_provider']);
    register_setting('agent_zero_settings_group', 'agent_zero_model', ['sanitize_callback' => 'agent_zero_sanitize_ai_model']);
    register_setting('agent_zero_settings_group', 'agent_zero_local_reply', ['sanitize_callback' => 'agent_zero_sanitize_yes_no']);
    register_setting('agent_zero_settings_group', 'agent_zero_auto_display', ['sanitize_callback' => 'agent_zero_sanitize_yes_no']);
    register_setting('agent_zero_settings_group', 'agent_zero_chat_bg', ['sanitize_callback' => 'agent_zero_sanitize_hex_color']);
    register_setting('agent_zero_settings_group', 'agent_zero_chat_text', ['sanitize_callback' => 'agent_zero_sanitize_hex_color']);
    register_setting('agent_zero_settings_group', 'agent_zero_avatar', ['sanitize_callback' => 'esc_url_raw']); // For URL
    register_setting('agent_zero_settings_group', 'agent_zero_bubble_bg', ['sanitize_callback' => 'agent_zero_sanitize_hex_color']);
    register_setting('agent_zero_settings_group', 'agent_zero_bubble_text', ['sanitize_callback' => 'agent_zero_sanitize_hex_color']);


    // Add a settings section
    add_settings_section(
        'agent_zero_main_section', // ID of the section
        'Main Settings',           // Title of the section
        null,                      // Callback function for section description (none needed here)
        'agent_zero_settings'      // Page slug where this section will appear
    );

    // Add individual settings fields to the section
    add_settings_field(
        'agent_zero_name',         // ID of the field
        'Agent Name',              // Title of the field
        function () { // Callback function to render the field's input
            echo '<input type="text" name="agent_zero_name" value="' . esc_attr(get_option('agent_zero_name')) . '" class="regular-text" />';
            echo '<p class="description">The name of your AI Assistant (e.g., "Agent Zero", "Your Bot").</p>';
        },
        'agent_zero_settings',     // Page slug
        'agent_zero_main_section'  // Section ID
    );

    add_settings_field(
        'agent_zero_api_provider',
        'AI API Provider',
        function () {
            $val = get_option('agent_zero_api_provider', 'google');
            echo '<select name="agent_zero_api_provider" id="agent_zero_api_provider">
                    <option value="openai" ' . selected($val, 'openai', false) . '>OpenAI</option>
                    <option value="groq" ' . selected($val, 'groq', false) . '>Groq</option>
                    <option value="google" ' . selected($val, 'google', false) . '>Google Gemini</option>
                    <option value="xai" ' . selected($val, 'xai', false) . '>xAI Grok</option>
                  </select>';
            echo '<p class="description">Choose the AI service to power your chatbot.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_model',
        'AI Model Name',
        function () {
            $provider = get_option('agent_zero_api_provider', 'google');
            $selected_model = get_option('agent_zero_model'); // Get the currently saved model
            $models = [
                'openai' => ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
                'groq' => ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'], // Corrected Groq models
                'google' => ['gemini-2.0-flash', 'gemini-2.0-pro'], // Corrected Google models
                'xai' => ['grok-1'] // Placeholder, adjust as needed
            ];

            // If the selected model is not in the list for the current provider,
            // default to the first model for that provider.
            if (!in_array($selected_model, $models[$provider] ?? []) && isset($models[$provider][0])) {
                $selected_model = $models[$provider][0];
                // No need to update_option here, as sanitization callback will handle it on save
            } elseif (!isset($models[$provider][0])) {
                $selected_model = 'N/A'; // No models available for this provider
            }


            echo '<select name="agent_zero_model" id="agent_zero_model_select">';
            if (isset($models[$provider])) {
                foreach ($models[$provider] as $m) {
                    echo '<option value="' . esc_attr($m) . '" ' . selected($selected_model, $m, false) . '>' . esc_html($m) . '</option>';
                }
            } else {
                echo '<option value="">No models available</option>';
            }
            echo '</select>';
            echo '<p class="description">Select the specific AI model to use. Options update based on provider.</p>';
            ?>
            <script>
            jQuery(document).ready(function($) {
                // Function to update models based on selected provider
                function updateModels() {
                    var provider = $('#agent_zero_api_provider').val();
                    var models = {
                        'openai': ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
                        'groq': ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
                        'google': ['gemini-2.0-flash', 'gemini-2.0-pro'],
                        'xai': ['grok-1']
                    };
                    var $modelSelect = $('#agent_zero_model_select');
                    $modelSelect.empty(); // Clear current options

                    if (models[provider]) {
                        // Add new options for the selected provider
                        $.each(models[provider], function(index, model) {
                            $modelSelect.append($('<option>', {
                                value: model,
                                text: model
                            }));
                        });
                        // Select the first model as default if no previous selection or invalid selection
                        // This logic should be mostly handled by PHP, but good for client-side too.
                        var currentModel = '<?php echo esc_js($selected_model); ?>';
                        if (models[provider].includes(currentModel)) {
                             $modelSelect.val(currentModel);
                        } else if (models[provider].length > 0) {
                            $modelSelect.val(models[provider][0]);
                        }
                    } else {
                        $modelSelect.append($('<option>', {
                            value: '',
                            text: 'No models available'
                        }));
                    }
                }

                // Initial call to set models based on current provider on page load
                updateModels();

                // Bind change event to API provider select
                $('#agent_zero_api_provider').change(function() {
                    updateModels();
                });
            });
            </script>
            <?php
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );


    add_settings_field(
        'agent_zero_api_key',
        'API Key',
        function () {
            echo '<input type="text" name="agent_zero_api_key" value="' . esc_attr(get_option('agent_zero_api_key')) . '" class="regular-text" placeholder="Your API Key for the selected service" />';
            echo '<p class="description">Enter your API key for the chosen AI provider. Keep this confidential!</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_local_reply',
        'Use Local Replies First',
        function () {
            $val = get_option('agent_zero_local_reply', 'yes');
            echo '<select name="agent_zero_local_reply">
                    <option value="yes"' . selected($val, 'yes', false) . '>Yes</option>
                    <option value="no"' . selected($val, 'no', false) . '>No</option>
                  </select>';
            echo '<p class="description">If enabled, the chatbot will check for predefined local replies before calling the AI API.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_auto_display',
        'Auto Display Chat on All Pages',
        function () {
            $val = get_option('agent_zero_auto_display', 'yes');
            echo '<select name="agent_zero_auto_display">
                    <option value="yes"' . selected($val, 'yes', false) . '>Yes</option>
                    <option value="no"' . selected($val, 'no', false) . '>No</option>
                  </select>';
            echo '<p class="description">Automatically show the chat bubble/widget on all frontend pages.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_chat_bg',
        'Chat Widget Background Color',
        function () {
            echo '<input type="color" name="agent_zero_chat_bg" value="' . esc_attr(get_option('agent_zero_chat_bg', '#e6e6fa')) . '" />';
            echo '<p class="description">Set the background color of the main chat widget.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_chat_text',
        'Chat Widget Text Color',
        function () {
            echo '<input type="color" name="agent_zero_chat_text" value="' . esc_attr(get_option('agent_zero_chat_text', '#333333')) . '" />';
            echo '<p class="description">Set the default text color within the chat widget.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_bubble_bg',
        'Chat Bubble Background Color',
        function () {
            echo '<input type="color" name="agent_zero_bubble_bg" value="' . esc_attr(get_option('agent_zero_bubble_bg', '#4a90e2')) . '" />';
            echo '<p class="description">Color of the floating chat bubble icon.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );

    add_settings_field(
        'agent_zero_bubble_text',
        'Chat Bubble Text Color',
        function () {
            echo '<input type="color" name="agent_zero_bubble_text" value="' . esc_attr(get_option('agent_zero_bubble_text', '#ffffff')) . '" />';
            echo '<p class="description">Color of the text/icon inside the floating chat bubble.</p>';
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );


    add_settings_field(
        'agent_zero_avatar',
        'Agent Avatar',
        function () {
            $img = esc_attr(get_option('agent_zero_avatar', AGENT_ZERO_PLUGIN_URL . 'assets/default-avatar.png'));
            echo '<input type="text" id="agent_zero_avatar" name="agent_zero_avatar" value="' . $img . '" class="regular-text" style="width:70%;" />';
            echo '<input type="button" class="button" value="Upload Image" id="agent_zero_avatar_upload">';
            echo '<p class="description">Select an image from your Media Library or upload a new one for the chatbot avatar.</p>';
            ?>
            <script>
            jQuery(document).ready(function($){
                var custom_uploader;
                $('#agent_zero_avatar_upload').click(function(e) {
                    e.preventDefault();
                    // If the uploader object has already been created, reopen the dialog
                    if (custom_uploader) {
                        custom_uploader.open();
                        return;
                    }
                    // Extend the wp.media object
                    custom_uploader = wp.media.frames.file_frame = wp.media({
                        title: 'Choose Agent Avatar',
                        button: {
                            text: 'Use this image'
                        },
                        multiple: false // Set to true to allow multiple files to be selected
                    });
                    // When a file is selected, grab the URL and set it as the text field's value
                    custom_uploader.on('select', function() {
                        var attachment = custom_uploader.state().get('selection').first().toJSON();
                        $('#agent_zero_avatar').val(attachment.url);
                    });
                    // Open the uploader dialog
                    custom_uploader.open();
                });
            });
            </script>
            <?php
        },
        'agent_zero_settings',
        'agent_zero_main_section'
    );
});
