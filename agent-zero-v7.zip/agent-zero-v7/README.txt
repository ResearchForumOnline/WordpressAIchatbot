Agent Zero v3.3 - AI Assistant WordPress Plugin

KEY FEATURES:

Editable knowledgebase (knowledgebase.txt) with 10MB limit

Editable agent identity (agent-metadata.json)

Multiple API provider selector (OpenAI, Groq, Google Gemini, xAI Grok - placeholder)

Dynamic model entry based on selected provider

Chatbot display on all pages (toggleable)

Fully editable local fallback replies

Uploadable chatbot avatar

Customizable chat widget and bubble colors

Responsive design for optimal viewing on all devices

Attribution: researchforum.online, talktoai.org, x.com/talktoai

No code editing required after initial setup

Installation:

Create a folder named 'agent-zero' in your WordPress 'wp-content/plugins/' directory.

Inside 'agent-zero', create 'admin', 'includes', and 'assets' subfolders.

Place 'default-avatar.png' (a small placeholder image) inside the 'assets' folder.

Create empty 'knowledgebase.txt', 'agent-metadata.json', and 'README.txt' files directly in 'agent-zero'.

Copy the content from the provided agent-zero.php, admin/zero-admin.php, and includes/zero-core.php files into their respective locations.

Zip the entire 'agent-zero' folder.

Upload the zipped file via WordPress Admin > Plugins > Add New > Upload Plugin.

Activate the plugin and configure settings under the new 'Agent Zero' menu item.